timemarks=[];
Hearing = data(:,1);
%Hearing = 0 - Hearing;
%inverting signal command, use the line above if you data appears upside
%down due the electrode configuration

Events = data(:,2);


for j=2:length(Events);
if Events(j)>0.4 
    if length(timemarks)>1
        if j - timemarks(end) >2300 %time between stimulations
            timemarks=[timemarks j];
        end         
    else timemarks=[timemarks j];
    end
end
end

% with buffer protection
% random_times = round(rand(length(timemarks),1).*length(Hearing));
% for k=1:length(random_times)
%     too_low=find(random_times < 100);
%     random_times(too_low) = [];
%     too_high=find(random_times > (length(Hearing)-499));
%     random_times(too_high)=[];
% end

%with no buffer protection
random_times = round(rand(length(timemarks),100).*length(Hearing));
for k=1:100
    too_low=find(random_times(:,k) < 100);
    inserts = round(rand(length(too_low),1).*length(Hearing));
    for l=1:length(inserts);
    if inserts(l)<100;
    insert_sub = round(rand(1).*length(Hearing)); 
    while insert(l)<100;
        insert_sub = round(rand(1).*length(Hearing)); 
    end
    inserts(l)=insert_sub;
    end
    end
    random_times(too_low,k)=inserts;
    
    too_high=find(random_times(:,k) > (length(Hearing)-499));
    inserts = round(rand(length(too_high),1).*length(Hearing));
    for l=1:length(inserts)
    if inserts(l)<100
    insert_sub = round(rand(1).*length(Hearing)); 
    while insert(l)>(length(Hearing)-499);
        insert_sub = round(rand(1).*length(Hearing)); 
    end
    inserts(l)=insert_sub;
    end
    end
    random_times(too_high,k)=inserts;
end

        
%build time series
time_series=zeros(1, length(Events));
for i = 2:length(Hearing);
    time_series(i)=((1/fs)*i)-(1/fs);
end

%hold on;
%plot(time_series, data)

Auditory_Matrix = zeros(length(timemarks), 600);
Random_Matrix = zeros(length(timemarks), 600,100);

for i=1:length(timemarks)
    Auditory_Matrix(i,:)=Hearing(timemarks(i)-99:timemarks(i)+500);
    for h = 1:100;
    Random_Matrix(i,:,h)=Hearing(random_times(i,h)-99:random_times(i,h)+500);
    end
end

ABR=mean(Auditory_Matrix,1);
ABR_Random_100=mean(Random_Matrix,1);
Monte_Carlo_Means=mean(ABR_Random_100,3);
Monte_Carlo_Std = std(ABR_Random_100,0,3);
Monte_Carlo_95_up = 2.*Monte_Carlo_Std;
Monte_Carlo_95_down = -2.*Monte_Carlo_Std;

ABR_time=(-9.9:0.1:50);





hold off;

plot(ABR_time, ABR);
hold on;
plot(ABR_time, Monte_Carlo_Means, 'r');
plot(ABR_time, Monte_Carlo_95_up, 'k');
plot(ABR_time, Monte_Carlo_95_down, 'k');
hold off;
ylim([-0.0004 0.0004])
xlim([-2 20])

