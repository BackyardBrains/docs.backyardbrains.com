﻿%%%This will plot the SpikerBox recordings, one the raw signal and one a
%%%post-processed version of the same signal. At 20 seconds experimenter
%%%began rhythmingly blowing on the cockroach leg. Notice increase in discharge.
%%%May 3rd, 2009 Backyard Brains, Tim Marzullo & Greg Gage
%%%Open first_recording.mat file and run this script to plot it.
%%%Downloadable at http://www.backyardbrains.com/first_recording.zip

subplot(2,1,1)
plot(x_time_points,signal_raw,'k');
ylabel('Voltage (scale unknown)');
title('Cockroach SpikerBox Raw Signal')
ylim([-0.5 0.5]);
xlim([0 35]);
subplot(2,1,2);
plot(x_time_points,signal_highpass_500Hz,'k');
xlabel('time (seconds)');
ylabel('Voltage (scale unknown)');
title('Cockroach SpikerBox HighPassed 500Hz')
ylim([-0.5 0.5]);
xlim([0 35]);