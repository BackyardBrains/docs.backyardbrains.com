%%%This will plot the Neural Recordings when they are imported into Matlab from a .wav file

gain = 880;
% you can change the gain to change the y-scale values

x_time_points = [1:size(data)]./fs;
% this creates a time series to give time-identity to your plot

plot(x_time_points,(data./gain), 'k');
%plots the rescaled data vs time, the ‘k’ just means print in black


ylabel('Voltage');
xlabel('time (seconds)');
title('My Neural Recordings');
% Just labels


