from microbit import *

# Set analog output period and center the servo on pin 8
pin8.set_analog_period(5)
pin8.write_analog(300)